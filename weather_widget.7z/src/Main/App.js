import React, { Component } from 'react';
import logo from '../logo.svg';
import WeatherWidget from '../WeatherWidget/index';
import Request from 'superagent';
import './App.css';

class App extends Component {

  
  state ={
    myWeatherObject : []
}
  
  componentWillMount(){

    var url = "https://api.openweathermap.org/data/2.5/forecast?id=524901&appid=70d8bfb74e35d57bf30beba273b1c277"
    Request.get(url).then((response) => {
        console.log(response.body);
        this.setState({
          myWeatherObject: response.body.list
      })
      
    });
}

  render() {

    console.log(this.state.myWeatherObject.length)
    if(this.state.myWeatherObject.length === 0) 
    {
      return <div >Loading...</div>
    }
else{

    return (
      <div className="App">
       
          <WeatherWidget  weatherData = {this.state.myWeatherObject}/>
        
      </div>

      
    );
  }
}
}

export default App;
