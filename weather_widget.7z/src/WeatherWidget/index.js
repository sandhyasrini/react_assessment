import React, {
    Component
} from 'react';


class WeatherWidget extends Component {

    state = {
        myWeatherObject: []
    }

    componentDidMount() {
        console.log(this.props.weatherData)
        this.setState({
            myWeatherObject: this.props.weatherData
        })
    }

    dateCalculations = () => {
        var today_date = new Date()
        console.log(this.state.myWeatherObject.length)

        let weater_by_day = {};

        if (this.state.myWeatherObject.length > 0) {
            this.state.myWeatherObject.forEach(element => {

                var ele = element.dt_txt.split(" ")[0].split("-")[2]
                if (!(ele in weater_by_day)) {
                    weater_by_day[ele] = [];
                }
                weater_by_day[ele].push(element);

            });
            console.log(weater_by_day)
        }
    }

    render() {
        this.dateCalculations();
        return (

            <div style = {
                {
                    color: "red",
                    fontSize: "20px",
                    width: "10%",
                    height: "200px"
                }
            } > {
                this.state.myWeatherObject.length > 0 ? this.state.myWeatherObject.length : this.state.myWeatherObject.length
            } </div>
        )
    }
}

export default WeatherWidget;